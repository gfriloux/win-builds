#ifdef HAVE_CONFIG_H
# include <config.h>
#endif

#ifdef HAVE_EVIL
# include <Evil.h>
#endif

#include "Ecore.h"
#include "ecore_private.h"

void
_ecore_exe_init(void)
{
}

void
_ecore_exe_shutdown(void)
{
}

