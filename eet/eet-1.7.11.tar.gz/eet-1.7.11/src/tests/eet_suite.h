#ifndef _EET_SUITE_H
# define _EET_SUITE_H

#include "Eet.h"

void
eet_test_setup_eddc(Eet_Data_Descriptor_Class *eddc);

#endif /* _EET_SUITE_H */
