#ifdef HAVE_CONFIG_H
# include <config.h>
#endif

#include "Evil.h"
#include "mingw32ce/errno.h"


int errno = 0;
