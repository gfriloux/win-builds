#define IEEE_8087
#define Arith_Kind_ASL 1
#define Double_Align
#ifdef _WIN64
#define X64_bit_pointers
#endif /* w64 */
