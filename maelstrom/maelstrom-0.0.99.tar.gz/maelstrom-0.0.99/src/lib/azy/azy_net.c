/*
 * Copyright 2010, 2011, 2012, 2013 Mike Blumenkrantz <michael.blumenkrantz@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 2.1 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "azy_private.h"

static const char *
_azy_net_proto_str(Azy_Net_Protocol proto)
{
   static char buf[128];

   switch (proto)
     {
      case AZY_NET_PROTOCOL_HTTP_1_0:
        strcpy(buf, "HTTP/1.0");
        break;

      case AZY_NET_PROTOCOL_HTTP_1_1:
        strcpy(buf, "HTTP/1.1");
        break;

      default:
        buf[0] = 0;
        break;
     }
   return buf;
}

/**
 * @defgroup Azy_Net Network Functions
 * @brief Functions which interact with the network transport
 * @{
 */
/* append a header hash to a strbuf */
static void
_azy_net_header_hash(Eina_Hash *hash EINA_UNUSED,
                     const char *key,
                     const char *data,
                     Eina_Strbuf *header)
{
   eina_strbuf_append_printf(header, "%s: %s\r\n", key, data);
}

/**
 * @brief Create a new #Azy_Net object
 *
 * This function is used to create an object which will store/manipulate
 * all network-related information.  Protocol defaults to HTTP 1.1.
 * @param conn Either an #Ecore_Con_Client or an #Ecore_Con_Server (NOT NULL)
 * @return A new #Azy_Net object, or NULL on failure/error
 */
Azy_Net *
azy_net_new(void *conn)
{
   Azy_Net *net;

   if (!conn) return NULL;

   net = calloc(1, sizeof(Azy_Net));
   EINA_SAFETY_ON_NULL_RETURN_VAL(net, NULL);
   net->conn = conn;
   net->refcount = 1;
   net->proto = AZY_NET_PROTOCOL_HTTP_1_1;

   AZY_MAGIC_SET(net, AZY_MAGIC_NET);
   return net;
}

/**
 * @brief Create a new #Azy_Net object from a buffer and content-type
 *
 * This function is used to create an object which will manipulate
 * previously downloaded network data.
 * @param buf The buffer to use
 * @param size The size of @p buf
 * @param transport The content-type of the data in the buffer
 * @param steal If true, @p buf should be considered as belonging to the returned object
 * @return A new #Azy_Net object, or NULL on failure/error
 */
Azy_Net *
azy_net_buffer_new(void *buf, size_t size, Azy_Net_Transport transport, Eina_Bool steal)
{
   Azy_Net *net;

   net = calloc(1, sizeof(Azy_Net));
   EINA_SAFETY_ON_NULL_RETURN_VAL(net, NULL);
   AZY_MAGIC_SET(net, AZY_MAGIC_NET);
   net->refcount = 1;
   if (buf && size)
     {
        if (steal)
          net->buffer = eina_binbuf_manage_new_length(buf, size);
        else
          {
             net->buffer = eina_binbuf_new();
             if (!net->buffer)
               {
                  free(net);
                  return NULL;
               }
             eina_binbuf_append_length(net->buffer, buf, size);
          }
     }
   net->transport = transport;
   return net;
}

/**
 * @brief Steal the contents of a network buffer
 *
 * This function can be used to clear the current buffer of a network
 * object. It is intended for use with AZY_EVENT_CLIENT_TRANSFER_PROGRESS events.
 * @param net The network object
 * @param size Pointer to store the size of the stolen buffer
 * @return the current content of the network buffer
 */
void *
azy_net_buffer_steal(Azy_Net *net, size_t *size)
{
   DBG("(net=%p)", net);

   if (!AZY_MAGIC_CHECK(net, AZY_MAGIC_NET))
     {
        AZY_MAGIC_FAIL(net, AZY_MAGIC_NET);
        return NULL;
     }
   if (size) *size = EBUFLEN(net->buffer);
   if (!net->buffer) return NULL;
   net->buffer_stolen = EINA_TRUE;
   return eina_binbuf_string_steal(net->buffer);
}

/**
 * @brief Free an #Azy_Net object
 *
 * This function frees an #Azy_Net object, including all data associated with it.
 * It does NOT free the Ecore_Con client/server object.
 * @param net The object to free
 */
void
azy_net_free(Azy_Net *net)
{
   DBG("(net=%p)", net);
   if (!net) return;
   if (!AZY_MAGIC_CHECK(net, AZY_MAGIC_NET))
     {
        AZY_MAGIC_FAIL(net, AZY_MAGIC_NET);
        return;
     }
   if (net->refcount) net->refcount--;
   if (net->refcount) return;
   eina_hash_free(net->http.headers);
   eina_stringshare_del(net->http.req.host);
   eina_stringshare_del(net->http.req.http_path);
   eina_stringshare_del(net->http.res.http_msg);
   if (net->buffer) eina_binbuf_free(net->buffer);
   azy_net_cookie_set_list_clear(net);
   azy_net_cookie_send_list_clear(net);
   if (net->http.post_headers) eina_hash_free(net->http.post_headers);
   if (net->http.post_headers_buf) eina_binbuf_free(net->http.post_headers_buf);
   if (net->overflow) eina_binbuf_free(net->overflow);
   if (net->separator) eina_strbuf_free(net->separator);
   if (net->timer) ecore_timer_del(net->timer);
   memset(net, 0, sizeof(Azy_Net)); /* zero out data for security */
   AZY_MAGIC_SET(net, AZY_MAGIC_NONE);
   free(net);
}

/**
 * @brief Find a value for a http header
 *
 * This function returns the http header value for the header name
 * specified.  For example, if name is "Connection", the return
 * might be "close"
 * @param net The #Azy_Net object to get the header from (NOT NULL)
 * @param name The name of the header (NOT NULL)
 * @return The value of the header, or NULL if header is not present
 */
const char *
azy_net_header_get(Azy_Net *net,
                   const char *name)
{
   const char *value;
   char *tmp;

   DBG("(net=%p)", net);

   if (!AZY_MAGIC_CHECK(net, AZY_MAGIC_NET))
     {
        AZY_MAGIC_FAIL(net, AZY_MAGIC_NET);
        return NULL;
     }

   if (!name)
     return NULL;

   tmp = strdupa(name);
   eina_str_tolower(&tmp);
   value = eina_hash_find(net->http.headers, tmp);

   return value;
}

/**
 * @brief Free all headers associated with @p net
 *
 * This function resets the http headers for @p net, freeing all
 * memory associated with them.
 * @param net The #Azy_Net object containing the headers to free (NOT NULL)
 */
void
azy_net_headers_reset(Azy_Net *net)
{
   DBG("(net=%p)", net);
   if (!AZY_MAGIC_CHECK(net, AZY_MAGIC_NET))
     {
        AZY_MAGIC_FAIL(net, AZY_MAGIC_NET);
        return;
     }

   if (!net->http.headers)
     return;

   eina_hash_free_buckets(net->http.headers);
   net->headers_read = EINA_FALSE;
}

/**
 * @brief Set up http basic auth headers using a name and password
 *
 * This function is used to set up http basic authentication using
 * base64 encoded copies of @p username and @p password strings.  If you don't know
 * what this is, see http://en.wikipedia.org/wiki/Basic_access_authentication
 * @param net The net object (NOT NULL)
 * @param username The username to use (NOT NULL)
 * @param password The password to use (NOT NULL)
 * @return #EINA_TRUE on success, else #EINA_FALSE
 */
Eina_Bool
azy_net_auth_set(Azy_Net *net,
                 const char *username,
                 const char *password)
{
   DBG("(net=%p)", net);
   char *enc_auth_str;
   Eina_Strbuf *str;

   if (!AZY_MAGIC_CHECK(net, AZY_MAGIC_NET))
     {
        AZY_MAGIC_FAIL(net, AZY_MAGIC_NET);
        return EINA_FALSE;
     }

   if ((!username) || (!password))
     return EINA_FALSE;

   if (!(str = eina_strbuf_new()))
     {
        ERR("Could not allocate memory!");
        return EINA_FALSE;
     }
   eina_strbuf_append_printf(str, "%s:%s", username, password);
   enc_auth_str = azy_util_base64_encode((void*)eina_strbuf_string_get(str), eina_strbuf_length_get(str), NULL);
   eina_strbuf_string_free(str);
   eina_strbuf_append_printf(str, "Basic %s", enc_auth_str);
   azy_net_header_set(net, "Authorization", NULL);
   azy_net_header_set(net, "Authorization", eina_strbuf_string_get(str));
   free(enc_auth_str);
   eina_strbuf_free(str);
   return EINA_TRUE;
}

/**
 * @brief Get username and password from http basic auth headers
 *
 * This function is used to get a http basic authentication username/password pair
 * using base64 encodes of @p username and @p password.  If you don't know
 * what this is, see http://en.wikipedia.org/wiki/Basic_access_authentication
 * @param net The net object (NOT NULL)
 * @param username A pointer to store the stringshared username in (NOT NULL)
 * @param password A pointer to store the stringshared password in (NOT NULL)
 * @return #EINA_TRUE on success, else #EINA_FALSE
 */
Eina_Bool
azy_net_auth_get(Azy_Net *net,
                 const char **username,
                 const char **password)
{
   DBG("(net=%p)", net);
   size_t auth_str_len, i;
   const char *enc_auth_str, *auth_header;
   char *auth_str;

   if (!AZY_MAGIC_CHECK(net, AZY_MAGIC_NET))
     {
        AZY_MAGIC_FAIL(net, AZY_MAGIC_NET);
        return EINA_FALSE;
     }

   if ((!username) || (!password))
     return EINA_FALSE;

   auth_header = azy_net_header_get(net, "Authorization");

   if ((!auth_header) || (!eina_str_has_prefix(auth_header, "Basic ")))
     return EINA_FALSE;

   enc_auth_str = auth_header + 6;
   auth_str = (char*)azy_util_base64_decode(enc_auth_str, strlen(enc_auth_str), &auth_str_len);

   if ((!auth_str) || (!auth_str_len))
     return EINA_FALSE;

   for (i = 0; i < auth_str_len; i++)
     if (auth_str[i] == ':')
       break;

   if (i == auth_str_len)
     {
        free(auth_str);
        return EINA_FALSE;
     }

   *username = eina_stringshare_add_length(auth_str, i);
   *password = eina_stringshare_add_length(auth_str + i + 1, auth_str_len - i - 1);

   free(auth_str);
   return EINA_TRUE;
}

/**
 * @brief Returns the http uri (path) that requests go to/came from
 *
 * This function returns the uri specified in the HTTP header.
 * Example:
 *  GET {/images/logo.png}<==URI HTTP/1.1
 * @param net The network object (NOT NULL)
 * @return The uri string, or NULL on error
 */
const char *
azy_net_uri_get(Azy_Net *net)
{
   DBG("(net=%p)", net);
   if (!AZY_MAGIC_CHECK(net, AZY_MAGIC_NET))
     {
        AZY_MAGIC_FAIL(net, AZY_MAGIC_NET);
        return NULL;
     }

   return net->http.req.http_path;
}

/**
 * @brief Sets the http uri (path) that requests go to/came from
 *
 * This function sets the uri specified in the HTTP header.
 * Example:
 *  GET {/images/logo.png}<==URI HTTP/1.1
 * @param net The network object (NOT NULL)
 * @param path The uri string (NOT NULL)
 * @return EINA_TRUE on success, else EINA_FALSE
 */
Eina_Bool
azy_net_uri_set(Azy_Net *net,
                const char *path)
{
   DBG("(net=%p)", net);
   if (!AZY_MAGIC_CHECK(net, AZY_MAGIC_NET))
     {
        AZY_MAGIC_FAIL(net, AZY_MAGIC_NET);
        return EINA_FALSE;
     }
   EINA_SAFETY_ON_NULL_RETURN_VAL(path, EINA_FALSE);

   net->http.req.http_path = eina_stringshare_add(path);
   return EINA_TRUE;
}

/**
 * @brief Returns the protocol used
 *
 * @param net The network object (NOT NULL)
 * @return #Azy_Net_Protocol, or AZY_NET_PROTOCOL_LAST on error
 */
Azy_Net_Protocol
azy_net_protocol_get(Azy_Net *net)
{
   DBG("(net=%p)", net);
   if (!AZY_MAGIC_CHECK(net, AZY_MAGIC_NET))
     {
        AZY_MAGIC_FAIL(net, AZY_MAGIC_NET);
        return AZY_NET_PROTOCOL_LAST;
     }

   return net->proto;
}

/**
 * @brief Set the http protocol version used
 *
 * This function sets the protocol version to be used in the @p net object.
 * Use 0 for http 1.0 or 1 for http 1.1.  Other values will return EINA_FALSE
 * @param net The network object (NOT NULL)
 * @param version 0 or 1 for relevant version
 * @return EINA_TRUE on success, else EINA_FALSE
 */
Eina_Bool
azy_net_protocol_set(Azy_Net *net, Azy_Net_Protocol proto)
{
   DBG("(net=%p)", net);
   if (!AZY_MAGIC_CHECK(net, AZY_MAGIC_NET))
     {
        AZY_MAGIC_FAIL(net, AZY_MAGIC_NET);
        return EINA_FALSE;
     }
   EINA_SAFETY_ON_TRUE_RETURN_VAL((proto >= AZY_NET_PROTOCOL_LAST), EINA_FALSE);

   net->proto = proto;
   return EINA_TRUE;
}

/**
 * @brief Return the status code of an http response
 *
 * This function returns the http status code from a response.
 * Some commonly used status codes are 404 (resource not found) and
 * 200 (OK).
 * @param net The network object (NOT NULL)
 * @return The status code or -1 on error
 */
int
azy_net_code_get(Azy_Net *net)
{
   DBG("(net=%p)", net);
   if (!AZY_MAGIC_CHECK(net, AZY_MAGIC_NET))
     {
        AZY_MAGIC_FAIL(net, AZY_MAGIC_NET);
        return -1;
     }

   return net->http.res.http_code;
}

/**
 * @brief Set the status code of an http response
 *
 * This function Sets the http status code for a response as well
 * as its corresponding http message (200 OK).
 * @param net The network object (NOT NULL)
 * @param code The status code
 * @return The status code or -1 on error
 */
void
azy_net_code_set(Azy_Net *net,
                 int code)
{
   DBG("(net=%p)", net);
   if (!AZY_MAGIC_CHECK(net, AZY_MAGIC_NET))
     {
        AZY_MAGIC_FAIL(net, AZY_MAGIC_NET);
        return;
     }

   net->http.res.http_code = code;
   net->http.res.http_msg = azy_net_http_msg_get(code);
}

/**
 * @brief Returns the http method used in the network object
 *
 * This function returns the #Azy_Net_Type of the http method used in @p net
 * which correspond to a matching method string (eg. AZY_NET_TYPE_GET == GET)
 * @param net The network object (NOT NULL)
 * @return The #Azy_Net_Type used, or #AZY_NET_TYPE_NONE on error
 */
Azy_Net_Type
azy_net_type_get(Azy_Net *net)
{
   DBG("(net=%p)", net);
   if (!AZY_MAGIC_CHECK(net, AZY_MAGIC_NET))
     {
        AZY_MAGIC_FAIL(net, AZY_MAGIC_NET);
        return AZY_NET_TYPE_NONE;
     }

   return net->type;
}

/**
 * @brief Sets the http method used in the network object
 *
 * This function sets the #Azy_Net_Type of the http method used in @p net
 * which correspond to a matching method string (eg. AZY_NET_TYPE_GET == GET)
 * @param net The network object (NOT NULL)
 * @param type The #Azy_Net_Type to be used
 */
void
azy_net_type_set(Azy_Net *net,
                 Azy_Net_Type type)
{
   DBG("(net=%p)", net);
   if (!AZY_MAGIC_CHECK(net, AZY_MAGIC_NET))
     {
        AZY_MAGIC_FAIL(net, AZY_MAGIC_NET);
        return;
     }
   if (((!type) || (type > AZY_NET_TYPE_RESPONSE_ERROR)))
     return;

   net->type = type;
}

/**
 * @brief Return the message length of a transmission
 *
 * This function is used to return the content-length set in the header
 * of @p net, and is equivalent to calling azy_net_header_get(net, "content-length").
 * @param net The network object (NOT NULL)
 * @return The content length, or -1 on error
 */
int
azy_net_content_length_get(Azy_Net *net)
{
   DBG("(net=%p)", net);
   if (!AZY_MAGIC_CHECK(net, AZY_MAGIC_NET))
     {
        AZY_MAGIC_FAIL(net, AZY_MAGIC_NET);
        return -1;
     }

   return net->http.content_length;
}

/**
 * @brief Set the message length of a transmission
 *
 * This function is used to set the content-length in the header
 * of @p net, but is NOT equivalent to calling
 * azy_net_header_set(net, "content-length", value).
 * @param net The network object (NOT NULL)
 * @param length The content length (length > 1)
 */
void
azy_net_content_length_set(Azy_Net *net,
                           int length)
{
   DBG("(net=%p)", net);
   char buf[64];

   if (!AZY_MAGIC_CHECK(net, AZY_MAGIC_NET))
     {
        AZY_MAGIC_FAIL(net, AZY_MAGIC_NET);
        return;
     }
   if (length < 1)
     return;

   net->http.content_length = length;
   snprintf(buf, sizeof(buf), "%i", length);
   azy_net_header_set(net, "content-length", NULL);
   azy_net_header_set(net, "content-length", buf);
}

/**
 * @brief Set a http header for use in a transmission
 *
 * This function is used to set an http header in @p net object. If
 * @p value is NULL, the header with @p name will be deleted.
 * @param net The network object (NOT NULL)
 * @param name The header's name (NOT NULL)
 * @param value The header's value
 */
void
azy_net_header_set(Azy_Net *net, const char *name, const char *value)
{
   DBG("(net=%p,name=%s,value=%s)", net, name, value);
   const char *old, *n;
   char *tmp;

   if (!AZY_MAGIC_CHECK(net, AZY_MAGIC_NET))
     {
        AZY_MAGIC_FAIL(net, AZY_MAGIC_NET);
        return;
     }

   EINA_SAFETY_ON_NULL_RETURN(name);
   EINA_SAFETY_ON_TRUE_RETURN(!name[0]);

   tmp = strdupa(name);
   eina_str_tolower(&tmp);

   if (EINA_UNLIKELY(!net->http.headers))
     {
        if (!value) return;
        net->http.headers = eina_hash_string_small_new((Eina_Free_Cb)eina_stringshare_del);
     }
   else if (!value)
     {
        eina_hash_del_by_key(net->http.headers, name);
        return;
     }

   n = eina_stringshare_add(value);
   if ((old = eina_hash_set(net->http.headers, tmp, n)))
     {
        /* FIXME: technically this is only legal for comma-separated lists... */
        eina_hash_set(net->http.headers, tmp, eina_stringshare_printf("%s,%s", old, value));
        eina_stringshare_del(old);
        eina_stringshare_del(n);
     }
   if (net->http.post_headers)
     {
        if (!eina_hash_del_by_key(net->http.post_headers, tmp))
          WARN("TRAILER HEADER (%s: %s) NOT SPECIFIED IN STARTING HEADERS!!!!!", name, value);
     }
}

/**
 * @brief Return the ip address associated with a network object
 *
 * This function returns the ip address of the client/server to which it represents.
 * Note that while the returned string is stringshared, it must not be freed since
 * it still belongs to @p net.
 * @param net The network object (NOT NULL)
 * @return The ip address, or NULL on failure
 */
const char *
azy_net_ip_get(Azy_Net *net)
{
   DBG("(net=%p)", net);
   if (!AZY_MAGIC_CHECK(net, AZY_MAGIC_NET))
     {
        AZY_MAGIC_FAIL(net, AZY_MAGIC_NET);
        return NULL;
     }

   if (net->server_client)
     return ecore_con_client_ip_get(net->conn);

   if (!ecore_con_server_connected_get(net->conn))
     return NULL;

   return ecore_con_server_ip_get(net->conn);
}

/**
 * @brief Set the http transport to be used in a network object
 *
 * This function is similar, but NOT the same as setting the "content-type"
 * header, as it sets internal variables to make type retrieval faster.
 * @param net The network object (NOT NULL)
 * @param transport The #Azy_Net_Transport to use
 */
void
azy_net_transport_set(Azy_Net *net,
                      Azy_Net_Transport transport)
{
   DBG("(net=%p)", net);
   if (!AZY_MAGIC_CHECK(net, AZY_MAGIC_NET))
     {
        AZY_MAGIC_FAIL(net, AZY_MAGIC_NET);
        return;
     }

   net->transport = transport;
   /* reset content-type header */
   azy_net_header_set(net, "content-type", NULL);
   if (transport == AZY_NET_TRANSPORT_XML)
     azy_net_header_set(net, "content-type", "text/xml");
   else if (transport == AZY_NET_TRANSPORT_JSON)
     azy_net_header_set(net, "content-type", "application/json");
}

/**
 * @brief Get the http transport used in a network object
 *
 * This function retrieves the #Azy_Net_Transport used in @p net,
 * representing the content-type.
 * @param net The network object (NOT NULL)
 * @return The #Azy_Net_Transport used, or #AZY_NET_TRANSPORT_UNKNOWN on failure
 */
Azy_Net_Transport
azy_net_transport_get(Azy_Net *net)
{
   DBG("(net=%p)", net);
   if (!AZY_MAGIC_CHECK(net, AZY_MAGIC_NET))
     {
        AZY_MAGIC_FAIL(net, AZY_MAGIC_NET);
        return AZY_NET_TRANSPORT_UNKNOWN;
     }
   return net->transport;
}

/**
 * @brief Create an http header string from data in a network object
 *
 * This function creates a full http header from data previously set in
 * @p net, including the http method line, content-type/length, and any others
 * which were set.
 * @param net The network object (NOT NULL)
 * @return A new #Eina_Strbuf containing the header string, or NULL on failure
 */
Eina_Strbuf *
azy_net_header_create(Azy_Net *net)
{
   Eina_Strbuf *header;

   DBG("(net=%p)", net);
   if (!AZY_MAGIC_CHECK(net, AZY_MAGIC_NET))
     {
        AZY_MAGIC_FAIL(net, AZY_MAGIC_NET);
        return NULL;
     }

   EINA_SAFETY_ON_TRUE_RETURN_VAL((!net->http.headers) &&
                                  (net->type == AZY_NET_TYPE_NONE) &&
                                  (net->transport == AZY_NET_TRANSPORT_UNKNOWN), NULL);

   header = eina_strbuf_new();
   switch (net->type)
     {
      case AZY_NET_TYPE_GET:
        eina_strbuf_append_printf(header, "GET %s %s\r\n",
                                  net->http.req.http_path, _azy_net_proto_str(net->proto));
        break;

      case AZY_NET_TYPE_POST:
        eina_strbuf_append_printf(header, "POST %s %s\r\n",
                                  net->http.req.http_path, _azy_net_proto_str(net->proto));
        break;

      case AZY_NET_TYPE_PUT:
        eina_strbuf_append_printf(header, "PUT %s %s\r\n",
                                  net->http.req.http_path, _azy_net_proto_str(net->proto));
        break;

      default:
        eina_strbuf_append_printf(header, "%s %d %s\r\n",
                                  _azy_net_proto_str(net->proto), net->http.res.http_code, net->http.res.http_msg);
        if ((net->http.res.http_code == 426) || (net->http.res.http_code == 101))
          {
             azy_net_header_set(net, "upgrade", "TLS/1.0, HTTP/1.1");
             azy_net_header_set(net, "connection", "Upgrade");
          }
     }

   if (net->http.headers)
     eina_hash_foreach(net->http.headers, (Eina_Hash_Foreach)_azy_net_header_hash, header);

   if (net->http.set_cookies) azy_net_cookie_set_list_generate(header, net->http.set_cookies);
   if (net->http.send_cookies) azy_net_cookie_send_list_generate(header, net->http.send_cookies);

   eina_strbuf_append(header, "\r\n");
   return header;
}

/**
 * @brief Get the currently-set HTTP transfer encoding for a network connection
 * @param net The network object
 * @return The #Azy_Net_Transfer_Encoding currently set
 */
Azy_Net_Transfer_Encoding
azy_net_transfer_encoding_get(const Azy_Net *net)
{
   DBG("(net=%p)", net);
   if (!AZY_MAGIC_CHECK(net, AZY_MAGIC_NET))
     {
        AZY_MAGIC_FAIL(net, AZY_MAGIC_NET);
        return AZY_NET_TRANSFER_ENCODING_LAST;
     }
   return net->http.transfer_encoding;
}

void
azy_net_transfer_encoding_set(Azy_Net *net,
                              Azy_Net_Transfer_Encoding transfer_encoding)
{
   DBG("(net=%p)", net);
   if (!AZY_MAGIC_CHECK(net, AZY_MAGIC_NET))
     {
        AZY_MAGIC_FAIL(net, AZY_MAGIC_NET);
        return;
     }
   net->http.transfer_encoding = transfer_encoding;

   if (transfer_encoding == AZY_NET_TRANSFER_ENCODING_CHUNKED)
     {
        azy_net_header_set(net, "Transfer-Encoding", "chunked");
        azy_net_header_set(net, "content_length", NULL);
     }
}

/**
 * @brief Return a stringshared http status string
 *
 * This function takes an http status code and returns a stringshared string
 * which corresponds to that code.
 * @param code The status code (NOT NULL)
 * @return The http status message for @p code
 */
const char *
azy_net_http_msg_get(int code)
{
   switch (code)
     {
      case 100:
        return eina_stringshare_add("Continue");

      case 101:
        return eina_stringshare_add("Switching Protocols");

      case 200:
        return eina_stringshare_add("OK");

      case 201:
        return eina_stringshare_add("Created");

      case 202:
        return eina_stringshare_add("Accepted");

      case 203:
        return eina_stringshare_add("Non-Authoritative Information");

      case 204:
        return eina_stringshare_add("No Content");

      case 205:
        return eina_stringshare_add("Reset Content");

      case 206:
        return eina_stringshare_add("Partial Content");

      case 300:
        return eina_stringshare_add("Multiple Choices");

      case 301:
        return eina_stringshare_add("Moved Permanently");

      case 302:
        return eina_stringshare_add("Found");

      case 303:
        return eina_stringshare_add("See Other");

      case 304:
        return eina_stringshare_add("Not Modified");

      case 305:
        return eina_stringshare_add("Use Proxy");

      case 306:
        return eina_stringshare_add("(Unused)");

      case 307:
        return eina_stringshare_add("Temporary Redirect");

      case 400:
        return eina_stringshare_add("Bad Request");

      case 401:
        return eina_stringshare_add("Unauthorized");

      case 402:
        return eina_stringshare_add("Payment Required");

      case 403:
        return eina_stringshare_add("Forbidden");

      case 404:
        return eina_stringshare_add("Not Found");

      case 405:
        return eina_stringshare_add("Method Not Allowed");

      case 406:
        return eina_stringshare_add("Not Acceptable");

      case 407:
        return eina_stringshare_add("Proxy Authentication Required");

      case 408:
        return eina_stringshare_add("Request Timeout");

      case 409:
        return eina_stringshare_add("Conflict");

      case 410:
        return eina_stringshare_add("Gone");

      case 411:
        return eina_stringshare_add("Length Required");

      case 412:
        return eina_stringshare_add("Precondition Failed");

      case 413:
        return eina_stringshare_add("Request Entity Too Large");

      case 414:
        return eina_stringshare_add("Request-URI Too Long");

      case 415:
        return eina_stringshare_add("Unsupported Media Type");

      case 416:
        return eina_stringshare_add("Requested Range Not Satisfiable");

      case 417:
        return eina_stringshare_add("Expectation Failed");

      case 426:
        return eina_stringshare_add("Upgrade Required");

      case 500:
        return eina_stringshare_add("Internal Server Error");

      case 501:
        return eina_stringshare_add("Not Implemented");

      case 502:
        return eina_stringshare_add("Bad Gateway");

      case 503:
        return eina_stringshare_add("Service Unavailable");

      case 504:
        return eina_stringshare_add("Gateway Timeout");

      case 505:
        return eina_stringshare_add("HTTP Version Not Supported");

      default:
        return eina_stringshare_add("Unknown Status");
     }
}

/** @} */
