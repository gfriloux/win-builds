#include "email_private.h"

Eina_Bool
email_pop3_retr_read(Email *e, Ecore_Con_Event_Server_Data *ev)
{
   Email_Retr_Cb cb;
   Email_Operation *op;
   size_t size;
   unsigned char *data;
   Eina_Bool tofree = EINA_TRUE;

   op = eina_list_data_get(e->ops);
   cb = op->cb;
   if ((!e->buf) && (!email_op_pop_ok(ev->data, ev->size)))
     {
        ERR("Error with RETR");
        if (cb && (!op->deleted)) cb(op, NULL);
        return EINA_TRUE;
     }
   if (e->buf)
     {
        eina_binbuf_append_length(e->buf, ev->data, ev->size);
        data = (unsigned char*)eina_binbuf_string_get(e->buf);
        size = eina_binbuf_length_get(e->buf);
     }
   else
     {
        data = memchr(ev->data, '\n', ev->size);
        if (!data) data = ev->data;
        size = ev->size - (data - (unsigned char*)ev->data);
        if (size && (data[0] == '\n')) data++, size--;
     }
   if (ev->size < 12) goto append; /* this is probably an error in the making */
   if (memcmp(data + size - 5, "\r\n.\r\n", 5)) goto append;

   if (!e->buf)
     {
        e->buf = eina_binbuf_new();
        eina_binbuf_append_length(e->buf, data, size);
     }

   INF("Message retrieved: %zu bytes", eina_binbuf_length_get(e->buf));
   if (cb && (!op->deleted)) tofree = !!cb(op, e->buf);
   if (tofree && e->buf) eina_binbuf_free(e->buf);
   e->buf = NULL;
   return EINA_TRUE;

append:
   if (!e->buf)
     {
        e->buf = eina_binbuf_new();
        eina_binbuf_append_length(e->buf, data, size);
     }
   return EINA_FALSE;
}
