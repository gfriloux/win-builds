#ifndef AUTOMATONdzh
#define AUTOMATONdzh
struct _cell{
	     int element;
	         struct _cell *next;
		   };
typedef struct _cell *List;
#endif
