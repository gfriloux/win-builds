
#ifndef  STRSTRSSE_INC
#define  STRSTRSSE_INC
#include "report.h"
//char *lstrstr (const char* , const char* );
//char *strstrsse (const char* , const char* );

#endif   /* ----- #ifndef STRSTRSSE_INC  ----- */
